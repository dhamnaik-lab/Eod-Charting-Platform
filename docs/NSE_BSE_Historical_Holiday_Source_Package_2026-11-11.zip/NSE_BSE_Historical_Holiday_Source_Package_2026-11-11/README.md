# NSE–BSE historical holiday sources — research package

**Research cut-off:** 11 November 2026 (IST). **Year-index range:** 1994–2026, inclusive. This is a source-discovery package, **not** a certified complete exchange trading calendar or a complete extract of holiday dates.

## What is included

- `NSE/SOURCES.md` — annual NSE Capital Market references and links.
- `BSE/SOURCES.md` — annual BSE equity references, primary notice URLs and independent corroboration.
- `NSE/by_year/YYYY.md` and `BSE/by_year/YYYY.md` — **66** audit-ready per-year Markdown source files (including explicit missing-year placeholders).
- `research/AMENDMENTS_AND_SPECIAL_SESSIONS.md` — known annual-calendar overrides, with exchange-specific sources.
- `research/GAPS_AND_RESEARCH_BACKLOG.md` — missing links and verification tasks.
- `research/METHODOLOGY_AND_SOURCE_GRADES.md` — provenance standards and appropriate usage.
- `research/OFFICIAL_PORTALS.md` — exchange portals to search for additional circulars.
- `source_inventory.csv` — machine-readable source index (records describe SOURCES, not holiday dates).
- `amendments_inventory.csv` — machine-readable known exceptions inventory.

## Coverage and honesty statement

- NSE: **20** calendar years with a direct official document, an exchange-issued reproduced document, or an independently corroborated reference (not all are direct-access primary files).
- BSE: **9** calendar years with a supported official notice ID or an official master circular. BSE serves 403 to automated requests for many notices.
- Do **not** interpret missing records as proof that no historical documents exist.
- Annual base calendars must be reconciled with additions, changed holidays and special opening sessions before deriving true trading days.
- The index begins in 1994 for manageable audit scope; BSE has a much longer history and this package **does not claim to cover its earlier years**.

## Priority discovery findings

1. NSE official press release from 26 Dec 2000 has the 2001 Capital Market and F&O holiday table.
2. NSE official annual Capital Market circulars are accessible for many years from 2006 through 2026, but the series has gaps (see yearly status).
3. BSE annual notice IDs can sometimes be corroborated through publisher-distributed copies even when its official original responds with 403.
4. In **2023**, Bakri Id moved from June 28 to June 29; the original annual calendar is not the final schedule.
5. The **2024** May 20 election holiday and **2026** Jan 15 election holiday were later amendments.
6. On **Saturday, 1 Feb 2025**, NSE held a live normal-hours trading session for the Union Budget.

## How to use

Start with `NSE/SOURCES.md` and `BSE/SOURCES.md`, then read `research/AMENDMENTS_AND_SPECIAL_SESSIONS.md`. For backtesting, derive a separate **validated session-date table** after reconciling actual market reports; this ZIP is **not** that derived table.

## Verification boundary

Sources were researched through web search and exchange-indexed texts. This environment could not mass-download official files. Links reflect documented search/fetch observations and are labeled accordingly; they were not all network-tested. There are no fabricated complete-year holiday date lists in this package.

# NSE — annual official historical holiday source index

Scope: equity trading / Capital Market segment. **A source index, not a normalized holiday calendar.**

| Year | Evidence grade | Ref | Link |
|---|---|---|---|
| [1994](by_year/1994.md) | `not_located` | — | — |
| [1995](by_year/1995.md) | `not_located` | — | — |
| [1996](by_year/1996.md) | `not_located` | — | — |
| [1997](by_year/1997.md) | `not_located` | — | — |
| [1998](by_year/1998.md) | `not_located` | — | — |
| [1999](by_year/1999.md) | `not_located` | — | — |
| [2000](by_year/2000.md) | `not_located` | — | — |
| [2001](by_year/2001.md) | `direct_official` | NSE press release 26 December 2000 | [NSE press release 26 December 2000](https://nsearchives.nseindia.com/content/press/26122000.pdf) |
| [2002](by_year/2002.md) | `not_located` | — | — |
| [2003](by_year/2003.md) | `not_located` | — | — |
| [2004](by_year/2004.md) | `not_located` | — | — |
| [2005](by_year/2005.md) | `not_located` | — | — |
| [2006](by_year/2006.md) | `direct_official` | NSE/CMTR/6946 | [NSE/CMTR/6946](https://nsearchives.nseindia.com/content/circulars/cmtr6946.htm) |
| [2007](by_year/2007.md) | `direct_official` | NSE/CMTR/8182 | [NSE/CMTR/8182](https://nsearchives.nseindia.com/content/circulars/cmtr8182.htm) |
| [2008](by_year/2008.md) | `reference_only` | NSE/CMTR/9908 | — |
| [2009](by_year/2009.md) | `direct_official` | NSE/CMTR/11733 | [NSE/CMTR/11733](https://nsearchives.nseindia.com/content/circulars/cmtr11733.htm) |
| [2010](by_year/2010.md) | `not_located` | — | — |
| [2011](by_year/2011.md) | `exchange_document_thirdparty` | NSE/CMTR/16348 | [NSE/CMTR/16348](https://www.isesec.com/Admin/Circular/20114899.pdf) |
| [2012](by_year/2012.md) | `exchange_document_thirdparty` | NSE/CMTR/19539 | [NSE/CMTR/19539](https://www.isesec.com/Admin/Circular/20111069.pdf) |
| [2013](by_year/2013.md) | `exchange_document_thirdparty` | NSE/CMTR/22317 | [NSE/CMTR/22317](https://www.rrfinance.com/Downloads/ZIP_Files/Common/NSE%20Trading%20Holidays%202013.pdf) |
| [2014](by_year/2014.md) | `not_located` | — | — |
| [2015](by_year/2015.md) | `direct_official` | NSE/CMTR/28337 | [NSE/CMTR/28337](https://nsearchives.nseindia.com/content/circulars/CMTR28337.pdf) |
| [2016](by_year/2016.md) | `exchange_document_thirdparty` | NSE/CMTR/31297 | [NSE/CMTR/31297](https://www.scribd.com/document/327543959/CMTR31297) |
| [2017](by_year/2017.md) | `direct_official` | NSE/CMTR/33746 | [NSE/CMTR/33746](https://nsearchives.nseindia.com/content/circulars/CMTR33746.pdf) |
| [2018](by_year/2018.md) | `direct_official` | NSE/CMTR/36475 | [NSE/CMTR/36475](https://nsearchives.nseindia.com/content/circulars/CMTR36475.pdf) |
| [2019](by_year/2019.md) | `direct_official` | NSE/CMTR/39612 | [NSE/CMTR/39612](https://nsearchives.nseindia.com/content/circulars/CMTR39612.pdf) |
| [2020](by_year/2020.md) | `direct_official` | NSE/CMTR/42877 | [NSE/CMTR/42877](https://nsearchives.nseindia.com/content/circulars/CMTR42877.pdf) |
| [2021](by_year/2021.md) | `direct_official` | NSE/CMTR/46623 | [NSE/CMTR/46623](https://archives.nseindia.com/content/circulars/CMTR46623.pdf) |
| [2022](by_year/2022.md) | `direct_official` | NSE/CMTR/50560 | [NSE/CMTR/50560](https://nsearchives.nseindia.com/content/circulars/CMTR50560.pdf) |
| [2023](by_year/2023.md) | `direct_official` | NSE/CMTR/54757 | [NSE/CMTR/54757](https://archives.nseindia.com/content/circulars/CMTR54757.pdf) |
| [2024](by_year/2024.md) | `direct_official` | NSE/CMTR/59722 | [NSE/CMTR/59722](https://archives.nseindia.com/content/circulars/CMTR59722.pdf) |
| [2025](by_year/2025.md) | `direct_official` | NSE/CMTR/65587 | [NSE/CMTR/65587](https://nsearchives.nseindia.com/content/circulars/CMTR65587.pdf) |
| [2026](by_year/2026.md) | `direct_official` | NSE/CMTR/71775 | [NSE/CMTR/71775](https://nsearchives.nseindia.com/content/circulars/CMTR71775.pdf) |

## Interpretation

`direct_official`: official-domain year-specific circular or press release accessible in search or opened. `direct_official_master_circular`: year calendar reproduced in a directly accessible official BSE master circular. `exchange_document_thirdparty`: exchange-authored circular reproduced on a third-party website; original host not independently accessible. `notice_id_corroborated`: official BSE notice ID independently reproduced but direct BSE fetch blocked. `reference_only`: circular number known from another source but annual source itself could not be checked. `not_located`: no acceptable annual source found.

See per-year files for corroborating mirrors and amendments; do not treat any baseline as final.

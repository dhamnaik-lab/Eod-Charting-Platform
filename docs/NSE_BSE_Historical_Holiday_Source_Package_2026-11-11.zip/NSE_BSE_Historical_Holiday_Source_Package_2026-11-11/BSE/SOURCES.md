# BSE — annual official historical holiday source index

Scope: equity trading / Capital Market segment. **A source index, not a normalized holiday calendar.**

| Year | Evidence grade | Ref | Link |
|---|---|---|---|
| [1994](by_year/1994.md) | `not_located` | — | — |
| [1995](by_year/1995.md) | `not_located` | — | — |
| [1996](by_year/1996.md) | `not_located` | — | — |
| [1997](by_year/1997.md) | `not_located` | — | — |
| [1998](by_year/1998.md) | `not_located` | — | — |
| [1999](by_year/1999.md) | `not_located` | — | — |
| [2000](by_year/2000.md) | `not_located` | — | — |
| [2001](by_year/2001.md) | `not_located` | — | — |
| [2002](by_year/2002.md) | `not_located` | — | — |
| [2003](by_year/2003.md) | `not_located` | — | — |
| [2004](by_year/2004.md) | `not_located` | — | — |
| [2005](by_year/2005.md) | `not_located` | — | — |
| [2006](by_year/2006.md) | `not_located` | — | — |
| [2007](by_year/2007.md) | `not_located` | — | — |
| [2008](by_year/2008.md) | `not_located` | — | — |
| [2009](by_year/2009.md) | `not_located` | — | — |
| [2010](by_year/2010.md) | `not_located` | — | — |
| [2011](by_year/2011.md) | `not_located` | — | — |
| [2012](by_year/2012.md) | `notice_id_corroborated` | BSE notice 20111125-18 | [BSE notice 20111125-18](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20111125-18) |
| [2013](by_year/2013.md) | `notice_id_corroborated` | BSE notice 20121217-21 | [BSE notice 20121217-21](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20121217-21) |
| [2014](by_year/2014.md) | `not_located` | — | — |
| [2015](by_year/2015.md) | `not_located` | — | — |
| [2016](by_year/2016.md) | `not_located` | — | — |
| [2017](by_year/2017.md) | `not_located` | — | — |
| [2018](by_year/2018.md) | `not_located` | — | — |
| [2019](by_year/2019.md) | `notice_id_corroborated` | BSE notice 20181207-13 | [BSE notice 20181207-13](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20181207-13) |
| [2020](by_year/2020.md) | `notice_id_corroborated` | BSE notice 20191211-2 | [BSE notice 20191211-2](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20191211-2) |
| [2021](by_year/2021.md) | `notice_id_corroborated` | BSE notice 20201210-7 | [BSE notice 20201210-7](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20201210-7) |
| [2022](by_year/2022.md) | `not_located` | — | — |
| [2023](by_year/2023.md) | `notice_id_corroborated` | BSE notice 20221208-31 | [BSE notice 20221208-31](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20221208-31) |
| [2024](by_year/2024.md) | `notice_id_corroborated` | BSE notice 20231212-40 | [BSE notice 20231212-40](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20231212-40) |
| [2025](by_year/2025.md) | `direct_official_master_circular` | BSE notice 20241213-30 | [BSE notice 20241213-30](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20241213-30) |
| [2026](by_year/2026.md) | `notice_id_corroborated` | BSE notice 20251212-8 | [BSE notice 20251212-8](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20251212-8) |

## Interpretation

`direct_official`: official-domain year-specific circular or press release accessible in search or opened. `direct_official_master_circular`: year calendar reproduced in a directly accessible official BSE master circular. `exchange_document_thirdparty`: exchange-authored circular reproduced on a third-party website; original host not independently accessible. `notice_id_corroborated`: official BSE notice ID independently reproduced but direct BSE fetch blocked. `reference_only`: circular number known from another source but annual source itself could not be checked. `not_located`: no acceptable annual source found.

See per-year files for corroborating mirrors and amendments; do not treat any baseline as final.

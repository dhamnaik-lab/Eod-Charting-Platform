# Source gaps and remaining verification backlog

**No claim of a complete historical daily closure dataset.** This section records the actual unresolved search scope.

- NSE years with no qualifying annual source: 1994, 1995, 1996, 1997, 1998, 1999, 2000, 2002, 2003, 2004, 2005, 2010, 2014.
- BSE years with no qualifying annual source: 1994, 1995, 1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2014, 2015, 2016, 2017, 2018, 2022.
- NSE annual links not directly available on an official exchange domain in the research: 2008 (only official reference), 2011, 2012, 2013, 2016 (exchange-authored copies at third-party hosts).
- BSE original annual notices are blocked in this environment for multiple recent years, although notice IDs are corroborated. Only official BSE 2025 master circular provided directly accessible year-level text.
- Any years outside 1994–2026, especially pre-1994 BSE history, are outside this audit register, not proven absent.

## Prioritized next checks

1. Search BSE notice archive by exact year, `Trading Holidays`, and `Equity`; obtain the final notice PDF/export, including 2000–2019.
2. Search NSE Capital Market archives for missing annual circulars 1994–2005, 2010 and 2014. Try late-November through December of the preceding year and early January of target year.
3. Locate NSE originals for 2008 CMTR/9908; 2011 CMTR/16348; 2012 CMTR/19539; 2013 CMTR/22317; 2016 CMTR/31297. Do not substitute similarly numbered MF, currency or SLB records.
4. Exhaust amendments and special live sessions for **each year** (especially election days, mourning closures, budget Saturdays, Diwali Muhurat, state holidays).
5. Obtain NSE and BSE actual daily trade reports or index prints to independently validate that each purported closure was closed; identify exchange-wide sessions separately from instrument-specific missing bars.
6. Build one normalized date-level CSV per exchange/segment with provenance per date, supersession rules, verification flags and final official source IDs.

## Specific high-priority ambiguities

- **2001:** an original NSE holiday table explicitly lists some Saturdays among dates; the exchange had evolving segment and weekend/session rules. Do not mechanically apply modern weekend assumptions to its older history.
- **2012:** BSE notice lists Bakri Id on 26 Oct but NSE CM equity reproduced circular does not include it in its main list. Treat exchanges separately and verify event-date amendments.
- **2014:** election closure notices exist indirectly (24 Apr and 15 Oct in broker archive), but no directly verified complete annual NSE/ BSE equity holiday notices were identified.
- **2023:** Bakri Id shifted to June 29, overriding the original base calendar.
- **2024:** Jan 20/22 special-schedule modifications need direct exchange notice inspection before final encoding; May 20 is independently confirmed.

## Resolution rule

Do not silently fill gaps from public holiday calendars, `holidays` Python packages, brokers, or the other exchange. Maintain an unresolved status until an official exchange circular or independent official session evidence resolves it.

# Amendments, overrides and exceptional sessions

This register is **not exhaustive**. It highlights verifiable high-impact counterexamples to using annual calendars alone.

| Exchange | Date(s) | Event type | Circular/notice | Evidence |
|---|---|---|---|---|
| NSE | 2008-10-28 | special_session | [NSE/CMTR/11371](https://nsearchives.nseindia.com/content/circulars/cmtr11371.htm) | `direct_official` |
| NSE | 2023-06-28 / 2023-06-29 | rescheduled_holiday | [NSE/CMTR/57285](https://www.niftyindices.com/Press_Release/ind_prs27062023.pdf) | `official_indirect` |
| BSE | 2023-06-28 / 2023-06-29 | rescheduled_holiday | [BSE notice 20230627-2](https://www.bseindia.com/markets/MarketInfo/DownloadAttach.aspx?attachedId=cb125690-a0f8-452a-ba6b-86cab98004bc&id=20230630-19) | `official_master_circular_reference` |
| NSE | 2024-05-20 | added_holiday | [NSE/CMTR/61518](https://nsearchives.nseindia.com/content/circulars/CMTR61518.pdf) | `direct_official` |
| BSE | 2024-05-20 | added_holiday | [BSE notice 20240408-25](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20240408-25) | `notice_id_corroborated` |
| NSE | 2024-01-20 / 2024-01-22 | exceptional_session_and_holiday | [NSE/CMTR/60338 and NSE/CMTR/60340 (cited by clearing circular)](https://nsearchives.nseindia.com/content/circulars/CMPT60343.pdf) | `official_indirect` |
| BSE | 2024-01-20 / 2024-01-22 | exceptional_session_and_holiday | [BSE notices 20240119-37 and 20240119-39 (cited by NSE Clearing)](https://nsearchives.nseindia.com/content/circulars/CMPT60343.pdf) | `official_indirect` |
| NSE | 2025-02-01 | special_live_trading_saturday | [NSE/CMTR/65729](https://nsearchives.nseindia.com/content/circulars/CMTR65729.pdf) | `direct_official` |
| NSE | 2026-01-15 | added_holiday | [NSE/CMTR/72260](https://nsearchives.nseindia.com/content/circulars/CMTR72260.pdf) | `direct_official` |
| BSE | 2026-01-15 | added_holiday | [BSE notice 20260112-8](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20260112-8) | `notice_id_corroborated` |

## Event details

### NSE — 2008 — 2008-10-28

Diwali Muhurat equity trading session held Tuesday 28 Oct 2008; confirms base 2008 circular CMTR/9908.

- Reference: `NSE/CMTR/11371`
- Evidence: [https://nsearchives.nseindia.com/content/circulars/cmtr11371.htm](https://nsearchives.nseindia.com/content/circulars/cmtr11371.htm)
- Retrieval / verification: `direct_official`

### NSE — 2023 — 2023-06-28 / 2023-06-29

NSE Indices 27 Jun 2023 press release confirms shift from 28 Jun (now trading) to 29 Jun (holiday). NSE CMTR/57285 original referenced, not directly retrievable.

- Reference: `NSE/CMTR/57285`
- Evidence: [https://www.niftyindices.com/Press_Release/ind_prs27062023.pdf](https://www.niftyindices.com/Press_Release/ind_prs27062023.pdf)
- Retrieval / verification: `official_indirect`

### BSE — 2023 — 2023-06-28 / 2023-06-29

BSE 2023 Equity Master Circular identifies a change in trading holiday; confirm final notice before import.

- Reference: `BSE notice 20230627-2`
- Evidence: [https://www.bseindia.com/markets/MarketInfo/DownloadAttach.aspx?attachedId=cb125690-a0f8-452a-ba6b-86cab98004bc&id=20230630-19](https://www.bseindia.com/markets/MarketInfo/DownloadAttach.aspx?attachedId=cb125690-a0f8-452a-ba6b-86cab98004bc&id=20230630-19)
- Retrieval / verification: `official_master_circular_reference`

### NSE — 2024 — 2024-05-20

Monday 20 May 2024 closed for Mumbai Parliamentary election (CM).

- Reference: `NSE/CMTR/61518`
- Evidence: [https://nsearchives.nseindia.com/content/circulars/CMTR61518.pdf](https://nsearchives.nseindia.com/content/circulars/CMTR61518.pdf)
- Retrieval / verification: `direct_official`

### BSE — 2024 — 2024-05-20

Monday 20 May 2024 closed for Mumbai Parliamentary election (Equity/F&O/SLB); BSE notice reproduced on Publicnow.

- Reference: `BSE notice 20240408-25`
- Evidence: [https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20240408-25](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20240408-25)
- Retrieval / verification: `notice_id_corroborated`

### NSE — 2024 — 2024-01-20 / 2024-01-22

NSE Clearing circular references Jan 20 live session and Jan 22 public holiday; verify exact market segment and session rules before data import.

- Reference: `NSE/CMTR/60338 and NSE/CMTR/60340 (cited by clearing circular)`
- Evidence: [https://nsearchives.nseindia.com/content/circulars/CMPT60343.pdf](https://nsearchives.nseindia.com/content/circulars/CMPT60343.pdf)
- Retrieval / verification: `official_indirect`

### BSE — 2024 — 2024-01-20 / 2024-01-22

Referenced by NSE Clearing; verify BSE primary notices before data import.

- Reference: `BSE notices 20240119-37 and 20240119-39 (cited by NSE Clearing)`
- Evidence: [https://nsearchives.nseindia.com/content/circulars/CMPT60343.pdf](https://nsearchives.nseindia.com/content/circulars/CMPT60343.pdf)
- Retrieval / verification: `official_indirect`

### NSE — 2025 — 2025-02-01

Budget day Saturday 1 Feb 2025 was normal-duration live equity trading, not a holiday; T+0 session excluded.

- Reference: `NSE/CMTR/65729`
- Evidence: [https://nsearchives.nseindia.com/content/circulars/CMTR65729.pdf](https://nsearchives.nseindia.com/content/circulars/CMTR65729.pdf)
- Retrieval / verification: `direct_official`

### NSE — 2026 — 2026-01-15

15 Jan 2026 closure for Maharashtra municipal corporation elections added to 2026 base calendar.

- Reference: `NSE/CMTR/72260`
- Evidence: [https://nsearchives.nseindia.com/content/circulars/CMTR72260.pdf](https://nsearchives.nseindia.com/content/circulars/CMTR72260.pdf)
- Retrieval / verification: `direct_official`

### BSE — 2026 — 2026-01-15

15 Jan 2026 closed for equity and derivatives; published BSE reproduction at https://bigul.co/pdf/20260112-8%201.pdf.

- Reference: `BSE notice 20260112-8`
- Evidence: [https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20260112-8](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20260112-8)
- Retrieval / verification: `notice_id_corroborated`

## Additional important distinctions

- Diwali holiday and Muhurat Trading may coexist on the same calendar date; do not encode it as a normal full trading day.
- A special Saturday trading day defeats a naive Monday-to-Friday calendar.
- Settlements and clearing holidays may differ from trading holidays.
- Outages, mock sessions, disaster-recovery tests and symbol-specific trading suspensions must not be represented as exchange-wide holidays.

# Methodology, scope and verification grades

## Scope

- Exchange: NSE and BSE (independent calendars).
- Segment: **NSE Capital Market / BSE Equity**, and equity derivatives only when explicitly covered by source.
- Years indexed: 1994–2026. This bounds the research; BSE started much earlier.
- Distinct things: exchange-wide full closure, partial segment holiday, settlement-only holiday, Muhurat special trading, weekend live trading, and unplanned market disruption.

## Evidence taxonomy

1. `direct_official`: Exchange-owned URL provides year-specific actual notice text / document and was indexed or opened.
2. `direct_official_master_circular`: Exchange-owned master circular reprints a year-specific original table; must check as-of date and later amendments.
3. `exchange_document_thirdparty`: Third-party site reproduces apparently original exchange-authored notice. Useful lead, lower confidence than exchange original.
4. `notice_id_corroborated`: Original notice ID and description corroborated in a third-party publisher, but direct BSE archive page returns 403 or cannot be retrieved. URL is an official **constructed canonical notice page from an evidenced notice ID**, not proof that the page was successfully fetched.
5. `reference_only`: Official reference number attested in a later exchange document, but baseline source not read.
6. `not_located`: no source established, not evidence of the absence of holiday dates.

## Rules for date-level use

- Collect every baseline notice and subsequent modification for the SAME segment and SAME exchange.
- Keep original notice publication date, event date, amendment/superseded status and primary document URL.
- Verify weekday names and chronology against calendar arithmetic, never use them to invent holidays.
- A date labeled `trading holiday` can host Muhurat Trading; represent it as a special session, not a standard trading day.
- A holiday on a Sunday generally does not add a second closed day, but a Sunday Muhurat session requires a separate event.
- Validate trading-session presence with exchange-wide daily summary / bhavcopy where available; no row for one security is **not** evidence of an exchange holiday.
- NSE/BSE sometimes differ, particularly historically. Do not assume dates are identical.
- Clearing, settlement and currency/commodity calendar dates cannot be substituted for equity closure dates.

## Data schema suggested for downstream datasets

`exchange,segment,date_ist,day_status,description,base_notice_ref,override_notice_ref,official_source_url,effective_notice_date,confidence,session_start_ist,session_end_ist,verified_by_market_data,notes`

Suggested `day_status`: `normal_trade`, `closed_holiday`, `special_live_trade`, `muhurat_trade`, `closed_exception`, `unresolved`.

## Limitations

- Source discovery is not exhaustive; a long history of silent amendments cannot be certified without full archive review.
- Many primary BSE URLs return automated 403. We provide verified IDs/alternate reproductions but do not claim that all official notice URLs were successfully opened.
- No CSV of daily holiday dates was generated, because the primary calendar and amendment coverage are not complete.

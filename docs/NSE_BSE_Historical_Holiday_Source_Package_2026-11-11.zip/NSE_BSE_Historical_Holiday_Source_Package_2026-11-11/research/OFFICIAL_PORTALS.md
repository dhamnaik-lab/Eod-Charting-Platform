# Official exchange source portals and supporting archives

## NSE

- [Market timings & current holidays](https://www.nseindia.com/resources/exchange-communication-holidays)
- [NSE official circulars search](https://www.nseindia.com/resources/exchange-communication-circulars)
- [NSE historical press releases](https://www.nseindia.com/static/resources/exchange-communication-press-releases-archives)
- [NSE 2025 segment-by-segment trade/clearing documents](https://www.nseindia.com/static/holidays-for-the-calendar-year-2025)
- [NSE Capital Market historical reports](https://www.nseindia.com/static/resources/historical-reports-capital-market-daily-monthly-archives)
- [NSE archive document host](https://nsearchives.nseindia.com/) (not a directory listing)
- [NSE Indices press release, June 27 2023](https://www.niftyindices.com/Press_Release/ind_prs27062023.pdf)

## BSE

- [BSE market holidays](https://www.bseindia.com/static/markets/marketinfo/listholi.aspx)
- [BSE notice/circular search](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx)
- [BSE official 2025 Equity Master Circular](https://www.bseindia.com/markets/MarketInfo/DownloadAttach.aspx?attachedId=8a7fec3a-95bc-4bd2-82de-76e2a84e2915&id=20250429-51)
- [BSE official 2023 Equity Master Circular](https://www.bseindia.com/markets/MarketInfo/DownloadAttach.aspx?attachedId=cb125690-a0f8-452a-ba6b-86cab98004bc&id=20230630-19)

**Access note:** BSE often blocks automated page fetching with 403. A valid notice ID and a generated canonical page link do **not** imply the link was fetched successfully by this research tool. The manual browser may work.

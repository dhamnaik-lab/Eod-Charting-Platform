# All historical NSE-BSE holiday source links (1994–2026)

See `README.md` for methodology. Direct official links versus third-party reproduced originals are labeled explicitly.

## NSE

# NSE — annual official historical holiday source index

Scope: equity trading / Capital Market segment. **A source index, not a normalized holiday calendar.**

| Year | Evidence grade | Ref | Link |
|---|---|---|---|
| [1994](by_year/1994.md) | `not_located` | — | — |
| [1995](by_year/1995.md) | `not_located` | — | — |
| [1996](by_year/1996.md) | `not_located` | — | — |
| [1997](by_year/1997.md) | `not_located` | — | — |
| [1998](by_year/1998.md) | `not_located` | — | — |
| [1999](by_year/1999.md) | `not_located` | — | — |
| [2000](by_year/2000.md) | `not_located` | — | — |
| [2001](by_year/2001.md) | `direct_official` | NSE press release 26 December 2000 | [NSE press release 26 December 2000](https://nsearchives.nseindia.com/content/press/26122000.pdf) |
| [2002](by_year/2002.md) | `not_located` | — | — |
| [2003](by_year/2003.md) | `not_located` | — | — |
| [2004](by_year/2004.md) | `not_located` | — | — |
| [2005](by_year/2005.md) | `not_located` | — | — |
| [2006](by_year/2006.md) | `direct_official` | NSE/CMTR/6946 | [NSE/CMTR/6946](https://nsearchives.nseindia.com/content/circulars/cmtr6946.htm) |
| [2007](by_year/2007.md) | `direct_official` | NSE/CMTR/8182 | [NSE/CMTR/8182](https://nsearchives.nseindia.com/content/circulars/cmtr8182.htm) |
| [2008](by_year/2008.md) | `reference_only` | NSE/CMTR/9908 | — |
| [2009](by_year/2009.md) | `direct_official` | NSE/CMTR/11733 | [NSE/CMTR/11733](https://nsearchives.nseindia.com/content/circulars/cmtr11733.htm) |
| [2010](by_year/2010.md) | `not_located` | — | — |
| [2011](by_year/2011.md) | `exchange_document_thirdparty` | NSE/CMTR/16348 | [NSE/CMTR/16348](https://www.isesec.com/Admin/Circular/20114899.pdf) |
| [2012](by_year/2012.md) | `exchange_document_thirdparty` | NSE/CMTR/19539 | [NSE/CMTR/19539](https://www.isesec.com/Admin/Circular/20111069.pdf) |
| [2013](by_year/2013.md) | `exchange_document_thirdparty` | NSE/CMTR/22317 | [NSE/CMTR/22317](https://www.rrfinance.com/Downloads/ZIP_Files/Common/NSE%20Trading%20Holidays%202013.pdf) |
| [2014](by_year/2014.md) | `not_located` | — | — |
| [2015](by_year/2015.md) | `direct_official` | NSE/CMTR/28337 | [NSE/CMTR/28337](https://nsearchives.nseindia.com/content/circulars/CMTR28337.pdf) |
| [2016](by_year/2016.md) | `exchange_document_thirdparty` | NSE/CMTR/31297 | [NSE/CMTR/31297](https://www.scribd.com/document/327543959/CMTR31297) |
| [2017](by_year/2017.md) | `direct_official` | NSE/CMTR/33746 | [NSE/CMTR/33746](https://nsearchives.nseindia.com/content/circulars/CMTR33746.pdf) |
| [2018](by_year/2018.md) | `direct_official` | NSE/CMTR/36475 | [NSE/CMTR/36475](https://nsearchives.nseindia.com/content/circulars/CMTR36475.pdf) |
| [2019](by_year/2019.md) | `direct_official` | NSE/CMTR/39612 | [NSE/CMTR/39612](https://nsearchives.nseindia.com/content/circulars/CMTR39612.pdf) |
| [2020](by_year/2020.md) | `direct_official` | NSE/CMTR/42877 | [NSE/CMTR/42877](https://nsearchives.nseindia.com/content/circulars/CMTR42877.pdf) |
| [2021](by_year/2021.md) | `direct_official` | NSE/CMTR/46623 | [NSE/CMTR/46623](https://archives.nseindia.com/content/circulars/CMTR46623.pdf) |
| [2022](by_year/2022.md) | `direct_official` | NSE/CMTR/50560 | [NSE/CMTR/50560](https://nsearchives.nseindia.com/content/circulars/CMTR50560.pdf) |
| [2023](by_year/2023.md) | `direct_official` | NSE/CMTR/54757 | [NSE/CMTR/54757](https://archives.nseindia.com/content/circulars/CMTR54757.pdf) |
| [2024](by_year/2024.md) | `direct_official` | NSE/CMTR/59722 | [NSE/CMTR/59722](https://archives.nseindia.com/content/circulars/CMTR59722.pdf) |
| [2025](by_year/2025.md) | `direct_official` | NSE/CMTR/65587 | [NSE/CMTR/65587](https://nsearchives.nseindia.com/content/circulars/CMTR65587.pdf) |
| [2026](by_year/2026.md) | `direct_official` | NSE/CMTR/71775 | [NSE/CMTR/71775](https://nsearchives.nseindia.com/content/circulars/CMTR71775.pdf) |

## Interpretation

`direct_official`: official-domain year-specific circular or press release accessible in search or opened. `direct_official_master_circular`: year calendar reproduced in a directly accessible official BSE master circular. `exchange_document_thirdparty`: exchange-authored circular reproduced on a third-party website; original host not independently accessible. `notice_id_corroborated`: official BSE notice ID independently reproduced but direct BSE fetch blocked. `reference_only`: circular number known from another source but annual source itself could not be checked. `not_located`: no acceptable annual source found.

See per-year files for corroborating mirrors and amendments; do not treat any baseline as final.


## BSE

# BSE — annual official historical holiday source index

Scope: equity trading / Capital Market segment. **A source index, not a normalized holiday calendar.**

| Year | Evidence grade | Ref | Link |
|---|---|---|---|
| [1994](by_year/1994.md) | `not_located` | — | — |
| [1995](by_year/1995.md) | `not_located` | — | — |
| [1996](by_year/1996.md) | `not_located` | — | — |
| [1997](by_year/1997.md) | `not_located` | — | — |
| [1998](by_year/1998.md) | `not_located` | — | — |
| [1999](by_year/1999.md) | `not_located` | — | — |
| [2000](by_year/2000.md) | `not_located` | — | — |
| [2001](by_year/2001.md) | `not_located` | — | — |
| [2002](by_year/2002.md) | `not_located` | — | — |
| [2003](by_year/2003.md) | `not_located` | — | — |
| [2004](by_year/2004.md) | `not_located` | — | — |
| [2005](by_year/2005.md) | `not_located` | — | — |
| [2006](by_year/2006.md) | `not_located` | — | — |
| [2007](by_year/2007.md) | `not_located` | — | — |
| [2008](by_year/2008.md) | `not_located` | — | — |
| [2009](by_year/2009.md) | `not_located` | — | — |
| [2010](by_year/2010.md) | `not_located` | — | — |
| [2011](by_year/2011.md) | `not_located` | — | — |
| [2012](by_year/2012.md) | `notice_id_corroborated` | BSE notice 20111125-18 | [BSE notice 20111125-18](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20111125-18) |
| [2013](by_year/2013.md) | `notice_id_corroborated` | BSE notice 20121217-21 | [BSE notice 20121217-21](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20121217-21) |
| [2014](by_year/2014.md) | `not_located` | — | — |
| [2015](by_year/2015.md) | `not_located` | — | — |
| [2016](by_year/2016.md) | `not_located` | — | — |
| [2017](by_year/2017.md) | `not_located` | — | — |
| [2018](by_year/2018.md) | `not_located` | — | — |
| [2019](by_year/2019.md) | `notice_id_corroborated` | BSE notice 20181207-13 | [BSE notice 20181207-13](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20181207-13) |
| [2020](by_year/2020.md) | `notice_id_corroborated` | BSE notice 20191211-2 | [BSE notice 20191211-2](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20191211-2) |
| [2021](by_year/2021.md) | `notice_id_corroborated` | BSE notice 20201210-7 | [BSE notice 20201210-7](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20201210-7) |
| [2022](by_year/2022.md) | `not_located` | — | — |
| [2023](by_year/2023.md) | `notice_id_corroborated` | BSE notice 20221208-31 | [BSE notice 20221208-31](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20221208-31) |
| [2024](by_year/2024.md) | `notice_id_corroborated` | BSE notice 20231212-40 | [BSE notice 20231212-40](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20231212-40) |
| [2025](by_year/2025.md) | `direct_official_master_circular` | BSE notice 20241213-30 | [BSE notice 20241213-30](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20241213-30) |
| [2026](by_year/2026.md) | `notice_id_corroborated` | BSE notice 20251212-8 | [BSE notice 20251212-8](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20251212-8) |

## Interpretation

`direct_official`: official-domain year-specific circular or press release accessible in search or opened. `direct_official_master_circular`: year calendar reproduced in a directly accessible official BSE master circular. `exchange_document_thirdparty`: exchange-authored circular reproduced on a third-party website; original host not independently accessible. `notice_id_corroborated`: official BSE notice ID independently reproduced but direct BSE fetch blocked. `reference_only`: circular number known from another source but annual source itself could not be checked. `not_located`: no acceptable annual source found.

See per-year files for corroborating mirrors and amendments; do not treat any baseline as final.


## Major post-publication amendments

# Amendments, overrides and exceptional sessions

This register is **not exhaustive**. It highlights verifiable high-impact counterexamples to using annual calendars alone.

| Exchange | Date(s) | Event type | Circular/notice | Evidence |
|---|---|---|---|---|
| NSE | 2008-10-28 | special_session | [NSE/CMTR/11371](https://nsearchives.nseindia.com/content/circulars/cmtr11371.htm) | `direct_official` |
| NSE | 2023-06-28 / 2023-06-29 | rescheduled_holiday | [NSE/CMTR/57285](https://www.niftyindices.com/Press_Release/ind_prs27062023.pdf) | `official_indirect` |
| BSE | 2023-06-28 / 2023-06-29 | rescheduled_holiday | [BSE notice 20230627-2](https://www.bseindia.com/markets/MarketInfo/DownloadAttach.aspx?attachedId=cb125690-a0f8-452a-ba6b-86cab98004bc&id=20230630-19) | `official_master_circular_reference` |
| NSE | 2024-05-20 | added_holiday | [NSE/CMTR/61518](https://nsearchives.nseindia.com/content/circulars/CMTR61518.pdf) | `direct_official` |
| BSE | 2024-05-20 | added_holiday | [BSE notice 20240408-25](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20240408-25) | `notice_id_corroborated` |
| NSE | 2024-01-20 / 2024-01-22 | exceptional_session_and_holiday | [NSE/CMTR/60338 and NSE/CMTR/60340 (cited by clearing circular)](https://nsearchives.nseindia.com/content/circulars/CMPT60343.pdf) | `official_indirect` |
| BSE | 2024-01-20 / 2024-01-22 | exceptional_session_and_holiday | [BSE notices 20240119-37 and 20240119-39 (cited by NSE Clearing)](https://nsearchives.nseindia.com/content/circulars/CMPT60343.pdf) | `official_indirect` |
| NSE | 2025-02-01 | special_live_trading_saturday | [NSE/CMTR/65729](https://nsearchives.nseindia.com/content/circulars/CMTR65729.pdf) | `direct_official` |
| NSE | 2026-01-15 | added_holiday | [NSE/CMTR/72260](https://nsearchives.nseindia.com/content/circulars/CMTR72260.pdf) | `direct_official` |
| BSE | 2026-01-15 | added_holiday | [BSE notice 20260112-8](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20260112-8) | `notice_id_corroborated` |

## Event details

### NSE — 2008 — 2008-10-28

Diwali Muhurat equity trading session held Tuesday 28 Oct 2008; confirms base 2008 circular CMTR/9908.

- Reference: `NSE/CMTR/11371`
- Evidence: [https://nsearchives.nseindia.com/content/circulars/cmtr11371.htm](https://nsearchives.nseindia.com/content/circulars/cmtr11371.htm)
- Retrieval / verification: `direct_official`

### NSE — 2023 — 2023-06-28 / 2023-06-29

NSE Indices 27 Jun 2023 press release confirms shift from 28 Jun (now trading) to 29 Jun (holiday). NSE CMTR/57285 original referenced, not directly retrievable.

- Reference: `NSE/CMTR/57285`
- Evidence: [https://www.niftyindices.com/Press_Release/ind_prs27062023.pdf](https://www.niftyindices.com/Press_Release/ind_prs27062023.pdf)
- Retrieval / verification: `official_indirect`

### BSE — 2023 — 2023-06-28 / 2023-06-29

BSE 2023 Equity Master Circular identifies a change in trading holiday; confirm final notice before import.

- Reference: `BSE notice 20230627-2`
- Evidence: [https://www.bseindia.com/markets/MarketInfo/DownloadAttach.aspx?attachedId=cb125690-a0f8-452a-ba6b-86cab98004bc&id=20230630-19](https://www.bseindia.com/markets/MarketInfo/DownloadAttach.aspx?attachedId=cb125690-a0f8-452a-ba6b-86cab98004bc&id=20230630-19)
- Retrieval / verification: `official_master_circular_reference`

### NSE — 2024 — 2024-05-20

Monday 20 May 2024 closed for Mumbai Parliamentary election (CM).

- Reference: `NSE/CMTR/61518`
- Evidence: [https://nsearchives.nseindia.com/content/circulars/CMTR61518.pdf](https://nsearchives.nseindia.com/content/circulars/CMTR61518.pdf)
- Retrieval / verification: `direct_official`

### BSE — 2024 — 2024-05-20

Monday 20 May 2024 closed for Mumbai Parliamentary election (Equity/F&O/SLB); BSE notice reproduced on Publicnow.

- Reference: `BSE notice 20240408-25`
- Evidence: [https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20240408-25](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20240408-25)
- Retrieval / verification: `notice_id_corroborated`

### NSE — 2024 — 2024-01-20 / 2024-01-22

NSE Clearing circular references Jan 20 live session and Jan 22 public holiday; verify exact market segment and session rules before data import.

- Reference: `NSE/CMTR/60338 and NSE/CMTR/60340 (cited by clearing circular)`
- Evidence: [https://nsearchives.nseindia.com/content/circulars/CMPT60343.pdf](https://nsearchives.nseindia.com/content/circulars/CMPT60343.pdf)
- Retrieval / verification: `official_indirect`

### BSE — 2024 — 2024-01-20 / 2024-01-22

Referenced by NSE Clearing; verify BSE primary notices before data import.

- Reference: `BSE notices 20240119-37 and 20240119-39 (cited by NSE Clearing)`
- Evidence: [https://nsearchives.nseindia.com/content/circulars/CMPT60343.pdf](https://nsearchives.nseindia.com/content/circulars/CMPT60343.pdf)
- Retrieval / verification: `official_indirect`

### NSE — 2025 — 2025-02-01

Budget day Saturday 1 Feb 2025 was normal-duration live equity trading, not a holiday; T+0 session excluded.

- Reference: `NSE/CMTR/65729`
- Evidence: [https://nsearchives.nseindia.com/content/circulars/CMTR65729.pdf](https://nsearchives.nseindia.com/content/circulars/CMTR65729.pdf)
- Retrieval / verification: `direct_official`

### NSE — 2026 — 2026-01-15

15 Jan 2026 closure for Maharashtra municipal corporation elections added to 2026 base calendar.

- Reference: `NSE/CMTR/72260`
- Evidence: [https://nsearchives.nseindia.com/content/circulars/CMTR72260.pdf](https://nsearchives.nseindia.com/content/circulars/CMTR72260.pdf)
- Retrieval / verification: `direct_official`

### BSE — 2026 — 2026-01-15

15 Jan 2026 closed for equity and derivatives; published BSE reproduction at https://bigul.co/pdf/20260112-8%201.pdf.

- Reference: `BSE notice 20260112-8`
- Evidence: [https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20260112-8](https://www.bseindia.com/markets/MarketInfo/DispNewNoticesCirculars.aspx?page=20260112-8)
- Retrieval / verification: `notice_id_corroborated`

## Additional important distinctions

- Diwali holiday and Muhurat Trading may coexist on the same calendar date; do not encode it as a normal full trading day.
- A special Saturday trading day defeats a naive Monday-to-Friday calendar.
- Settlements and clearing holidays may differ from trading holidays.
- Outages, mock sessions, disaster-recovery tests and symbol-specific trading suspensions must not be represented as exchange-wide holidays.
